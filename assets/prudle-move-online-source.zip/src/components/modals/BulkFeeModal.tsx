import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface BulkFeeModalProps {
  isOpen: boolean;
  selectedCount: number;
  onClose: () => void;
  onApply: (courseFee: number | null, paidAmount: number | null) => Promise<void>;
  lang: Language;
}

export const BulkFeeModal: React.FC<BulkFeeModalProps> = ({
  isOpen,
  selectedCount,
  onClose,
  onApply,
  lang
}) => {
  const t = translations[lang];
  const [courseFeeInput, setCourseFeeInput] = useState<string>('');
  const [paidAmountInput, setPaidAmountInput] = useState<string>('');
  const [applying, setApplying] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleApply = async () => {
    const feeVal = courseFeeInput.trim() === '' ? null : Number(courseFeeInput);
    const paidVal = paidAmountInput.trim() === '' ? null : Number(paidAmountInput);

    if (feeVal === null && paidVal === null) {
      alert(t.alertEnterFeeOrPaid);
      return;
    }

    setApplying(true);
    try {
      await onApply(feeVal, paidVal);
      setCourseFeeInput('');
      setPaidAmountInput('');
      onClose();
    } catch (err) {
      console.error(err);
      alert(t.alertFeesError);
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-box">
        <h3>{t.modalBulkFeesTitle}</h3>
        <div className="sub">
          {t.modalBulkFeesSub}
          {selectedCount}
          {t.modalBulkFeesRecords}
        </div>

        <label>{t.lblNewCourseFee}</label>
        <input
          type="number"
          min="0"
          step="1"
          placeholder="e.g. 1500"
          value={courseFeeInput}
          onChange={(e) => setCourseFeeInput(e.target.value)}
        />

        <label>{t.lblNewPaidAmount}</label>
        <input
          type="number"
          min="0"
          step="1"
          placeholder="e.g. 0"
          value={paidAmountInput}
          onChange={(e) => setPaidAmountInput(e.target.value)}
        />

        <div className="modal-actions">
          <button
            className="btn-gray"
            type="button"
            disabled={applying}
            onClick={onClose}
          >
            {t.btnCancel}
          </button>
          <button
            className="btn-blue"
            type="button"
            disabled={applying}
            onClick={handleApply}
          >
            {applying ? t.btnApplying : t.btnApply}
          </button>
        </div>
      </div>
    </div>
  );
};
