import { callWorkerDb } from './authService';
import { CourseRecord, LevelInfo, StudentRecord, StudentSource, UndoRecord } from '../types';

// In-flight read deduplication cache
const inFlightRequests = new Map<string, Promise<any>>();

function executeDeduplicatedQuery(key: string, queryFn: () => Promise<any>): Promise<any> {
  const existing = inFlightRequests.get(key);
  if (existing) return existing;

  const promise = queryFn().finally(() => {
    inFlightRequests.delete(key);
  });
  inFlightRequests.set(key, promise);
  return promise;
}

export function cleanDigits(val: any): string {
  return String(val || '').replace(/\D/g, '');
}

export function safeNumber(val: any, fallback = 0): number {
  const n = Number(val);
  return isNaN(n) ? fallback : n;
}

export function safePositiveNumber(val: any): number {
  const n = safeNumber(val, 0);
  return n < 0 ? 0 : n;
}

export function formatDateStr(val: any): string {
  try {
    if (!val) return '';
    if (val.toDate && typeof val.toDate === 'function') {
      return val.toDate().toISOString().slice(0, 10);
    }
    if (val instanceof Date) {
      return val.toISOString().slice(0, 10);
    }
    if (typeof val === 'number') {
      return new Date(val).toISOString().slice(0, 10);
    }
    const s = String(val);
    return s.length >= 10 ? s.slice(0, 10) : '';
  } catch {
    return '';
  }
}

function normalizeDocData(doc: any): Record<string, any> {
  if (!doc) return {};
  if (doc.data && typeof doc.data === 'object' && !Array.isArray(doc.data)) return doc.data;
  if (doc.fields && typeof doc.fields === 'object') return doc.fields;
  return doc;
}

/**
 * Perform query on /db with deduplication.
 */
export async function queryCollection(
  collection: string,
  filters: Array<{ field: string; op: string; value: any }> = [],
  orderBy?: { field: string; direction: 'asc' | 'desc' },
  limit = 200
): Promise<any[]> {
  const cacheKey = JSON.stringify({ collection, filters, orderBy, limit });

  return executeDeduplicatedQuery(cacheKey, async () => {
    const payload: Record<string, any> = {
      action: 'query',
      collection,
      filters,
      limit
    };
    if (orderBy) {
      payload.orderBy = [orderBy];
    }

    const res = await callWorkerDb(payload);
    const docs = res?.data?.documents || res?.documents || res?.data?.docs || res?.snapshot?.docs || res?.docs || [];
    return Array.isArray(docs) ? docs : [];
  });
}

export async function getDoc(path: string): Promise<Record<string, any> | null> {
  const res = await callWorkerDb({ action: 'getDoc', path });
  const doc = res?.data?.document || res?.document || res?.data || res;
  if (!doc || doc.exists === false || doc.found === false) return null;
  return normalizeDocData(doc);
}

export async function setDoc(path: string, data: Record<string, any>, merge = true): Promise<any> {
  return callWorkerDb({
    action: 'setDoc',
    path,
    data,
    merge
  });
}

export async function deleteDoc(path: string): Promise<any> {
  return callWorkerDb({
    action: 'deleteDoc',
    path
  });
}

// Memory cache for student levels by Iqama
const levelsCache = new Map<string, LevelInfo | null>();

/**
 * Look up student's past levels record from the `students` collection by Iqama.
 */
export async function lookupStudentLevels(rawIqama: string): Promise<LevelInfo | null> {
  const iqama = cleanDigits(rawIqama);
  if (!iqama) return null;

  if (levelsCache.has(iqama)) {
    return levelsCache.get(iqama) || null;
  }

  const parseLevel = (docData: Record<string, any>): LevelInfo => ({
    total: Number(docData.totalLevels || 0),
    used: Number(docData.usedLevels || 0),
    remaining: Number(docData.remainingLevels || 0)
  });

  // Try query by promotedAt desc
  try {
    const docs = await queryCollection('students', [{ field: 'iqama', op: '==', value: iqama }], { field: 'promotedAt', direction: 'desc' }, 1);
    if (docs.length > 0) {
      const data = normalizeDocData(docs[0]);
      const parsed = parseLevel(data);
      levelsCache.set(iqama, parsed);
      return parsed;
    }
  } catch {}

  // Fallback query by createdAt desc
  try {
    const docs = await queryCollection('students', [{ field: 'iqama', op: '==', value: iqama }], { field: 'createdAt', direction: 'desc' }, 1);
    if (docs.length > 0) {
      const data = normalizeDocData(docs[0]);
      const parsed = parseLevel(data);
      levelsCache.set(iqama, parsed);
      return parsed;
    }
  } catch {}

  // Fallback simple limit 20
  try {
    const docs = await queryCollection('students', [{ field: 'iqama', op: '==', value: iqama }], undefined, 20);
    if (docs.length > 0) {
      const sorted = docs.map(normalizeDocData).sort((a, b) => {
        const timeA = a.promotedAt?.toDate ? a.promotedAt.toDate().getTime() : a.createdAt?.toDate ? a.createdAt.toDate().getTime() : new Date(a.createdAt || 0).getTime() || 0;
        const timeB = b.promotedAt?.toDate ? b.promotedAt.toDate().getTime() : b.createdAt?.toDate ? b.createdAt.toDate().getTime() : new Date(b.createdAt || 0).getTime() || 0;
        return timeB - timeA;
      });
      const parsed = parseLevel(sorted[0]);
      levelsCache.set(iqama, parsed);
      return parsed;
    }
  } catch {}

  levelsCache.set(iqama, null);
  return null;
}

/**
 * Fetch all staging student records from FakeRegistrations and FakePromotions.
 */
export async function fetchStagingStudents(): Promise<StudentRecord[]> {
  const regFilters1 = [
    { field: 'Branch', op: '==', value: 'Al-Jumum' },
    { field: 'CourseType', op: '==', value: 'حضوري' }
  ];
  const regFilters2 = [
    { field: 'branch', op: '==', value: 'Al-Jumum' },
    { field: 'mode', op: '==', value: 'حضوري' }
  ];

  // Fetch concurrently
  const [regs1, regs2, proms1, proms2] = await Promise.all([
    queryCollection('FakeRegistrations', regFilters1, undefined, 500).catch(() => []),
    queryCollection('FakeRegistrations', regFilters2, undefined, 500).catch(() => []),
    queryCollection('FakePromotions', regFilters1, undefined, 500).catch(() => []),
    queryCollection('FakePromotions', regFilters2, undefined, 500).catch(() => [])
  ]);

  const uniqueDocs = new Map<string, { src: StudentSource; doc: any }>();

  [...regs1, ...regs2].forEach((d) => {
    const id = String(d.id || d.__name__ || '');
    if (id && !uniqueDocs.has(`FakeRegistrations__${id}`)) {
      uniqueDocs.set(`FakeRegistrations__${id}`, { src: 'FakeRegistrations', doc: d });
    }
  });

  [...proms1, ...proms2].forEach((d) => {
    const id = String(d.id || d.__name__ || '');
    if (id && !uniqueDocs.has(`FakePromotions__${id}`)) {
      uniqueDocs.set(`FakePromotions__${id}`, { src: 'FakePromotions', doc: d });
    }
  });

  const studentsList: StudentRecord[] = [];

  for (const { src, doc } of uniqueDocs.values()) {
    const id = String(doc.id || doc.__name__ || '');
    const data = normalizeDocData(doc);

    const branch = data.Branch || data.branch || '';
    const courseType = data.CourseType || data.mode || '';
    if (branch !== 'Al-Jumum' || courseType !== 'حضوري') continue;

    const courseFee = safeNumber(data.CourseFee ?? data.courseFee, 0);
    const paidAmount = safeNumber(data.PaidAmount ?? data.paidAmount, 0);
    const remainingAmount = safePositiveNumber(data.RemainingAmount ?? data.remainingAmount ?? (courseFee - paidAmount));
    const paymentType = data.PaymentType || data.paymentType || data.PaymentMethod || data.paymentMethod || '';

    const course = data.course?.name || data.TrainingCourse || data.courseName || data.fromLevel || data.currentCourse || '';
    const period = data.Period || data.period || data.PeriodName || data.course?.Period || data.course?.period || '';
    const room = data.Room || data.room || data.course?.Room || data.course?.room || '';
    const trainer = data.Trainer || data.trainer || data.course?.Trainer || data.course?.trainer || '';

    const name_en = String(data.name_en || data.name || '').trim();
    const name_ar = String(data.name_ar || '').trim();
    const age = cleanDigits(data.age);
    const iqama = cleanDigits(data.iqama);
    const phone = cleanDigits(data.phone);
    const date = formatDateStr(data.createdAt || data.date || data.Date || data.created_at);

    if (src === 'FakeRegistrations') {
      studentsList.push({
        src,
        id,
        raw: data,
        name_en,
        name: name_en,
        name_ar,
        age,
        iqama,
        phone,
        course,
        previousCourse: '',
        period,
        room,
        trainer,
        totalLevels: '—',
        usedLevels: '—',
        remainingLevels: '—',
        _lastLevels: null,
        CourseFee: courseFee,
        PaidAmount: paidAmount,
        RemainingAmount: remainingAmount,
        PaymentType: paymentType,
        grade: '—',
        status: 'new',
        date
      });
    } else {
      // FakePromotions
      const previousCourse = data.previousCourse?.name || data.fromCourse?.name || data.fromLevel || '';
      const rawGrade = data.grade ?? data.finalGrade ?? data.final ?? data.totalGrade;
      const numGrade = Number(rawGrade);
      const hasGrade = !(rawGrade === null || rawGrade === undefined || rawGrade === '' || isNaN(numGrade));

      const status: 'new' | 'pass' | 'fail' = hasGrade ? (numGrade >= 65 ? 'pass' : 'fail') : 'new';

      studentsList.push({
        src,
        id,
        raw: data,
        name_en,
        name: name_en,
        name_ar,
        age,
        iqama,
        phone,
        course,
        previousCourse,
        period,
        room,
        trainer,
        totalLevels: '—',
        usedLevels: '—',
        remainingLevels: '—',
        _lastLevels: null,
        CourseFee: courseFee,
        PaidAmount: paidAmount,
        RemainingAmount: remainingAmount,
        PaymentType: paymentType,
        grade: hasGrade ? numGrade : '—',
        status,
        date
      });
    }
  }

  return studentsList;
}

/**
 * Resolve student levels in batches concurrently without locking initial rendering.
 */
export async function populateStudentLevels(students: StudentRecord[]): Promise<StudentRecord[]> {
  const uniqueIqamas = [...new Set(students.map((s) => s.iqama).filter(Boolean))];

  // Batch lookup up to 8 concurrently
  const concurrency = 8;
  let idx = 0;

  const worker = async () => {
    while (idx < uniqueIqamas.length) {
      const iq = uniqueIqamas[idx++];
      try {
        await lookupStudentLevels(iq);
      } catch {}
    }
  };

  const tasks: Promise<void>[] = [];
  for (let i = 0; i < Math.min(concurrency, uniqueIqamas.length); i++) {
    tasks.push(worker());
  }
  await Promise.all(tasks);

  return students.map((s) => {
    if (!s.iqama) return s;
    const lvl = levelsCache.get(s.iqama);
    if (!lvl) return s;

    const raw = s.raw || {};
    const total = raw.totalLevels ?? raw.TotalLevels ?? lvl.total ?? '—';
    const used = raw.usedLevels ?? raw.UsedLevels ?? lvl.used ?? '—';
    const remaining = raw.remainingLevels ?? raw.RemainingLevels ?? lvl.remaining ?? '—';

    return {
      ...s,
      totalLevels: total,
      usedLevels: used,
      remainingLevels: remaining,
      _lastLevels: lvl
    };
  });
}

/**
 * Subscribe to open courses for Al-Jumum in-person branch.
 */
export function subscribeToOpenCourses(
  onCourses: (courses: CourseRecord[]) => void,
  onError?: (err: any) => void
): () => void {
  let active = true;

  const fetchCourses = async () => {
    if (!active) return;
    try {
      const filters = [
        { field: 'status', op: '==', value: 'open' },
        { field: 'Branch', op: '==', value: 'Al-Jumum' },
        { field: 'CourseType', op: '==', value: 'حضوري' }
      ];
      const docs = await queryCollection('Courses', filters, undefined, 100);
      if (!active) return;

      const courses: CourseRecord[] = docs.map((d) => {
        const data = normalizeDocData(d);
        return {
          id: String(d.id || d.__name__ || ''),
          ...data
        };
      });
      onCourses(courses);
    } catch (err) {
      if (!active) return;
      if (onError) onError(err);
    }
  };

  fetchCourses();
  const intervalId = setInterval(fetchCourses, 12000);

  return () => {
    active = false;
    clearInterval(intervalId);
  };
}

/**
 * Migrate a student into the `students` collection and delete from source.
 */
export async function migrateStudentRecord(
  student: StudentRecord,
  targetCourse: CourseRecord,
  totalLevels: number,
  courseFee: number,
  paidAmount: number,
  remainingAmount: number
): Promise<{ newStudentId: string; undoRecord: UndoRecord }> {
  const period = targetCourse.Period || targetCourse.period || student.period || '';
  const nowTimestamp = {
    __type: 'timestamp',
    value: new Date().toISOString()
  };

  const newDocPayload = {
    name: student.name_en || student.name || '',
    StudentName: student.name_en || student.name || '',
    name_en: student.name_en || student.name || '',
    name_ar: student.name_ar || '',
    iqama: student.iqama || '',
    phone: student.phone || '',
    age: student.age || '',
    courseId: targetCourse.id,
    TrainingCourse: targetCourse.TrainingCourse || '',
    Period: period,
    period: period,
    Trainer: targetCourse.Trainer || '',
    Room: targetCourse.Room || targetCourse.room || '',
    Branch: targetCourse.Branch || 'Al-Jumum',
    Section: targetCourse.Section || '',
    CourseType: targetCourse.CourseType || 'حضوري',
    totalLevels,
    usedLevels: safeNumber(student.usedLevels, 0),
    remainingLevels: safeNumber(student.remainingLevels, 0),
    CourseFee: courseFee,
    PaidAmount: paidAmount,
    RemainingAmount: remainingAmount,
    PaymentType: student.PaymentType || '',
    StudentFee: courseFee,
    AmountPaid: paidAmount,
    Remaining: remainingAmount,
    PaymentMethod: student.PaymentType || '',
    promotedAt: nowTimestamp
  };

  // Generate unique doc ID or call setDoc
  const randomSuffix = Array.from(crypto.getRandomValues(new Uint8Array(15)), (b) =>
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'[b % 62]
  ).join('');
  const newStudentId = `std_${Date.now()}_${randomSuffix}`;

  await setDoc(`students/${newStudentId}`, newDocPayload, false);

  // Delete from source staging collection
  await deleteDoc(`${student.src}/${student.id}`);

  const undoRecord: UndoRecord = {
    type: 'migrate',
    src: student.src,
    id: student.id,
    raw: student.raw,
    studentId: newStudentId
  };

  return { newStudentId, undoRecord };
}

/**
 * Undo a previous migration by removing student from `students` and restoring source.
 */
export async function undoStudentRecord(undoRecord: UndoRecord): Promise<void> {
  if (undoRecord.type === 'migrate' && undoRecord.studentId) {
    try {
      await deleteDoc(`students/${undoRecord.studentId}`);
    } catch (e) {
      console.warn('Could not delete migrated student during undo:', e);
    }
  }

  // Restore raw record back to source
  await setDoc(`${undoRecord.src}/${undoRecord.id}`, undoRecord.raw, false);
}

/**
 * Delete a student record with undo capability.
 */
export async function deleteStudentRecord(student: StudentRecord): Promise<UndoRecord> {
  await deleteDoc(`${student.src}/${student.id}`);
  return {
    type: 'delete',
    src: student.src,
    id: student.id,
    raw: student.raw
  };
}

/**
 * Update a single inline field on a staging student document.
 */
export async function updateStudentField(
  student: StudentRecord,
  field: string,
  value: string
): Promise<void> {
  let finalValue: any = value.trim();
  if (field === 'age' || field === 'iqama' || field === 'phone') {
    finalValue = cleanDigits(finalValue);
  }

  await setDoc(`${student.src}/${student.id}`, { [field]: finalValue }, true);
}

/**
 * Update fee amounts on a staging student document.
 */
export async function updateStudentFees(
  student: StudentRecord,
  courseFee: number,
  paidAmount: number,
  remainingAmount: number,
  paymentType: string
): Promise<void> {
  await setDoc(`${student.src}/${student.id}`, {
    CourseFee: courseFee,
    PaidAmount: paidAmount,
    RemainingAmount: remainingAmount,
    PaymentType: paymentType
  }, true);
}

/**
 * Update level fields on a staging student document.
 */
export async function updateStudentLevels(
  student: StudentRecord,
  totalLevels: number,
  usedLevels: number,
  remainingLevels: number
): Promise<void> {
  await setDoc(`${student.src}/${student.id}`, {
    totalLevels,
    usedLevels,
    remainingLevels
  }, true);
}

/**
 * Import student rows into FakeRegistrations from Excel.
 */
export async function importExcelRows(rows: Record<string, any>[]): Promise<number> {
  let count = 0;
  for (const row of rows) {
    const name_en = String(row['name_en'] || row['الاسم EN'] || row['name'] || row['الاسم'] || '').trim();
    if (!name_en) continue;

    const name_ar = String(row['name_ar'] || row['الاسم AR'] || '').trim();
    const age = cleanDigits(row['age'] || row['العمر']);
    const iqama = cleanDigits(row['iqama'] || row['الهوية']);
    const phone = cleanDigits(row['phone'] || row['الجوال']);
    const fee = safeNumber(row['CourseFee'] || row['الرسوم'], 0);
    const paid = safeNumber(row['PaidAmount'] || row['المدفوع'], 0);
    const rem = safePositiveNumber(fee - paid);

    const randomSuffix = Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) =>
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'[b % 62]
    ).join('');
    const id = `reg_${Date.now()}_${randomSuffix}`;

    await setDoc(`FakeRegistrations/${id}`, {
      name_en,
      name: name_en,
      name_ar,
      age,
      iqama,
      phone,
      Branch: 'Al-Jumum',
      CourseType: 'حضوري',
      CourseFee: fee,
      PaidAmount: paid,
      RemainingAmount: rem,
      createdAt: {
        __type: 'timestamp',
        value: new Date().toISOString()
      }
    }, false);
    count++;
  }
  return count;
}
